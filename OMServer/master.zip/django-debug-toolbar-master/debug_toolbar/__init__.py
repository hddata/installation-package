VERSION = (0, 8, 5)
__version__ = '.'.join(map(str, VERSION))
